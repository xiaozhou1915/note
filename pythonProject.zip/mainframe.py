# -*- coding:utf-8 -*-
import tkinter as tk
from math import floor

class mainframey:
    window = tk.Tk()
    paned =tk.PanedWindow(window, showhandle=False)
    def __init__(self):
        self.window = tk.Tk()
        self.window.title('超级笔记本')
        self.window.iconbitmap('F:/javaNiXiangGongju/jeb-4.20.0.202210051834/bin/jeb.ico')
        self.window["background"] = "#C9C9C9"
        windowW = floor(self.window.winfo_screenwidth() * 3 / 4)
        windowH = floor(self.window.winfo_screenheight() * 3 / 4)
        # 屏幕居中
        window_size = f'{windowW}x{windowH}+{round((self.window.winfo_screenwidth() - windowW) / 2)}+{round((self.window.winfo_screenheight() - windowH) / 2)}'  # round去掉小数
        self.window.geometry(window_size)
        self.window.minsize(50, 50)
        # 底框
        self.paned.pack(fill=tk.BOTH, expand=1)

