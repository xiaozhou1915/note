

# -*- coding:utf-8 -*-
import tkinter as tk
from math import floor
from tkinter import messagebox
import mainframe

#左侧框
mainframes = mainframe.mainframey()
panda = mainframes.paned
leftframe =tk.Frame(panda,width=200,height=300)
leftframe.pack()
panda.add(leftframe)
searchframe =tk.Frame(leftframe,width=300)
searchentry =tk.Entry(searchframe)
searchButton =tk.Button(searchframe,text="搜索")
searchentry.pack(side=tk.LEFT)
searchframe.pack()
searchButton.pack(side=tk.RIGHT)
showtext =tk.Frame(leftframe,width=300)
showtext.pack()
#滚轮
sbar1= tk.Scrollbar(showtext)
# 将滚动条放置在右侧，并设置当窗口大小改变时滚动条会沿着垂直方向延展
sbar1.pack(side=tk.LEFT, fill=tk.Y)
mylist = tk.Listbox(showtext, yscrollcommand=sbar1.set)
for i in range(30):
    mylist.insert(tk.END, '第' + str(i + 1) + '次:' + 'C语言中文网，网址为：c.biancheng.net' + '\n')
# 当窗口改变大小时会在X与Y方向填满窗口
mylist.pack(side=tk.LEFT, fill=tk.BOTH)
#右侧框
rightframe =tk.Frame(paned,width=300,bg="green")
rightframe.pack()

paned.add(rightframe)
if __name__ == '__main__':
    mainframe.window.mainloop()
